#!/bin/sh

HW=04
PROGRAM=./b0b36prp-hw$HW-genref

if [ "$1" = "osx" ]
then
   echo "Build for osx has been selected."
   PROGRAM=./b0b36prp-hw$HW-genref-osx
fi

if [ "$1" = "fbsd" ]
then
   echo "Build for fbsd has been selected."
   PROGRAM=./b0b36prp-hw$HW-genref-fbsd
fi



mkdir -p files
for i in `seq 1 4`
do
   PROBLEM=files/hw$HW-$i
   echo "Generate random input '$PROBLEM.in'"
   $PROGRAM -generate > $PROBLEM.in 2>/dev/null
   echo "Solve '$PROBLEM.in' and store the reference solution to '$PROBLEM.out'"
   $PROGRAM < $PROBLEM.in > $PROBLEM.out 2>$PROBLEM.err
done

